const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(__dirname, 'tasks.json');

app.use(bodyParser.json());

let tasks = [];

try {
    const data = fs.readFileSync(DATA_FILE, 'utf8');
    tasks = JSON.parse(data);
} catch (err) {
    if (err.code === 'ENOENT') {
        fs.writeFileSync(DATA_FILE, JSON.stringify(tasks, null, 2));
    } else {
        console.error('Error reading tasks file:', err);
    }
}

function saveTasks() {
    fs.writeFile(DATA_FILE, JSON.stringify(tasks, null, 2), (err) => {
        if (err) console.error('Error saving tasks:', err);
    });
}

app.get('/api/tasks', (req, res) => {
    res.json(tasks);
});

app.post('/api/tasks', (req, res) => {
    const { title, description } = req.body;
    
    if (!title) {
        return res.status(400).json({ error: 'Title is required' });
    }

    const newTask = {
        id: tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1,
        title,
        description: description || '',
        completed: false,
        createdAt: new Date().toISOString()
    };

    tasks.push(newTask);
    saveTasks();
    res.status(201).json(newTask);
});

app.put('/api/tasks/:id', (req, res) => {
    const taskId = parseInt(req.params.id);
    const task = tasks.find(t => t.id === taskId);

    if (!task) {
        return res.status(404).json({ error: 'Task not found' });
    }

    task.completed = true;
    task.updatedAt = new Date().toISOString();
    saveTasks();
    res.json(task);
});

app.delete('/api/tasks/:id', (req, res) => {
    const taskId = parseInt(req.params.id);
    const taskIndex = tasks.findIndex(t => t.id === taskId);

    if (taskIndex === -1) {
        return res.status(404).json({ error: 'Task not found' });
    }

    const [deletedTask] = tasks.splice(taskIndex, 1);
    saveTasks();
    res.json(deletedTask);
});

app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Task API</title>
            <style>
                body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
                h1 { color: #333; }
                .status { background: #f0f0f0; padding: 20px; border-radius: 5px; }
                .endpoints { margin-top: 20px; }
                .endpoint { margin-bottom: 10px; padding: 10px; background: #e9f7fe; border-radius: 3px; }
            </style>
        </head>
        <body>
            <h1>Task Management API</h1>
            <div class="status">
                <p>API is running and ready to accept requests</p>
            </div>
            <div class="endpoints">
                <h2>Available Endpoints:</h2>
                <div class="endpoint">
                    <strong>GET /api/tasks</strong> - Retrieve all tasks
                </div>
                <div class="endpoint">
                    <strong>POST /api/tasks</strong> - Create a new task (requires title in body)
                </div>
                <div class="endpoint">
                    <strong>PUT /api/tasks/:id</strong> - Mark a task as completed
                </div>
                <div class="endpoint">
                    <strong>DELETE /api/tasks/:id</strong> - Delete a task
                </div>
            </div>
        </body>
        </html>
    `);
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});